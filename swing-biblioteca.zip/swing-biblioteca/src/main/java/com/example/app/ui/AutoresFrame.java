package com.example.app.ui;

import com.example.app.model.Autor;
import com.example.app.service.AutorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AutoresFrame extends JFrame {
    private final AutorService service = new AutorService();
    private final JTextField txtId = new JTextField();
    private final JTextField txtNombre = new JTextField();
    private final JTextField txtNacionalidad = new JTextField();
    private final JTextField txtBuscar = new JTextField();
    private final JTable table = new JTable();

    public AutoresFrame(Frame owner) {
        setTitle("CRUD Autores");
        setSize(720, 520);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(8,8));

        JPanel form = new JPanel(new GridLayout(3,2,6,6));
        form.setBorder(BorderFactory.createTitledBorder("Formulario"));
        txtId.setEditable(false);
        form.add(new JLabel("ID")); form.add(txtId);
        form.add(new JLabel("Nombre")); form.add(txtNombre);
        form.add(new JLabel("Nacionalidad")); form.add(txtNacionalidad);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 6,6));
        JButton btnNuevo = new JButton("Nuevo/Limpiar");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnListar = new JButton("Listar");
        acciones.add(btnNuevo); acciones.add(btnGuardar); acciones.add(btnModificar); acciones.add(btnEliminar); acciones.add(btnListar);

        JPanel top = new JPanel(new BorderLayout(6,6));
        JPanel search = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6,6));
        search.add(new JLabel("Buscar:")); search.add(txtBuscar);
        top.add(form, BorderLayout.CENTER); top.add(acciones, BorderLayout.SOUTH); top.add(search, BorderLayout.NORTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnNuevo.addActionListener(e -> limpiar());
        btnListar.addActionListener(e -> cargarTabla());
        btnGuardar.addActionListener(e -> guardar(false));
        btnModificar.addActionListener(e -> guardar(true));
        btnEliminar.addActionListener(e -> eliminar());
        txtBuscar.getDocument().addDocumentListener(SimpleDocListener.onChange(this::cargarTabla));
        table.getSelectionModel().addListSelectionListener(e -> seleccionar());

        cargarTabla();
    }

    private void cargarTabla() {
        try {
            List<Autor> data = service.listar(txtBuscar.getText());
            DefaultTableModel m = new DefaultTableModel(new Object[]{"ID","Nombre","Nacionalidad"},0) {
                @Override public boolean isCellEditable(int r, int c){ return false; }
            };
            for (Autor a : data) m.addRow(new Object[]{a.getId(), a.getNombre(), a.getNacionalidad()});
            table.setModel(m);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error listando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar(boolean modificar) {
        try {
            Autor a = new Autor();
            if (modificar) {
                if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona un autor"); return; }
                a.setId(Integer.parseInt(txtId.getText()));
            }
            a.setNombre(txtNombre.getText().trim());
            a.setNacionalidad(txtNacionalidad.getText().trim());
            service.guardar(a);
            JOptionPane.showMessageDialog(this, "Guardado correctamente");
            limpiar(); cargarTabla();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error guardando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminar() {
        try {
            if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona un autor"); return; }
            int id = Integer.parseInt(txtId.getText());
            int opt = JOptionPane.showConfirmDialog(this, "¿Eliminar autor ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (opt == JOptionPane.YES_OPTION) {
                service.eliminar(id);
                JOptionPane.showMessageDialog(this, "Eliminado");
                limpiar(); cargarTabla();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error eliminando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void seleccionar() {
        int r = table.getSelectedRow();
        if (r >= 0) {
            txtId.setText(String.valueOf(table.getValueAt(r,0)));
            txtNombre.setText(String.valueOf(table.getValueAt(r,1)));
            txtNacionalidad.setText(String.valueOf(table.getValueAt(r,2)));
        }
    }

    private void limpiar() {
        txtId.setText(""); txtNombre.setText(""); txtNacionalidad.setText("");
        table.clearSelection();
    }
}
