package com.example.app.ui;

import com.example.app.model.User;
import com.example.app.service.AuthService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class LoginFrame extends JFrame {
    private final JTextField txtUser = new JTextField();
    private final JPasswordField txtPass = new JPasswordField();
    private final JButton btnLogin = new JButton("Iniciar sesión");
    private final AuthService authService = new AuthService();

    public LoginFrame() {
        setTitle("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(360, 220);
        setLocationRelativeTo(null);
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(14,14,14,14));
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL; c.insets = new Insets(6,6,6,6);

        c.gridx=0;c.gridy=0;p.add(new JLabel("Usuario"), c);
        c.gridx=1;c.gridy=0;p.add(txtUser, c);
        c.gridx=0;c.gridy=1;p.add(new JLabel("Contraseña"), c);
        c.gridx=1;c.gridy=1;p.add(txtPass, c);
        c.gridx=1;c.gridy=2;p.add(btnLogin, c);

        txtUser.setColumns(16);
        txtPass.addKeyListener(new KeyAdapter() { @Override public void keyPressed(KeyEvent e){ if(e.getKeyCode()==KeyEvent.VK_ENTER) login(); }});
        btnLogin.addActionListener(e -> login());
        setContentPane(p);
    }

    private void login() {
        try {
            String u = txtUser.getText().trim();
            String p = new String(txtPass.getPassword());
            User user = authService.login(u, p);
            JOptionPane.showMessageDialog(this, "¡Bienvenido " + user.getUsername() + "!");
            new MainFrame(user).setVisible(true);
            dispose();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al iniciar sesión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
