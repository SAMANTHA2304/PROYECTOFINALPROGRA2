package com.example.app.ui;

import com.example.app.model.Categoria;
import com.example.app.service.CategoriaService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CategoriasFrame extends JFrame {
    private final CategoriaService service = new CategoriaService();
    private final JTextField txtId = new JTextField();
    private final JTextField txtNombre = new JTextField();
    private final JTextField txtBuscar = new JTextField();
    private final JTable table = new JTable();

    public CategoriasFrame(Frame owner) {
        setTitle("CRUD Categorías");
        setSize(640, 480);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(8,8));

        JPanel form = new JPanel(new GridLayout(1,2,6,6));
        form.setBorder(BorderFactory.createTitledBorder("Formulario"));
        txtId.setEditable(false);
        form.add(new JLabel("ID")); form.add(txtId);
        form.add(new JLabel("Nombre")); form.add(txtNombre);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 6,6));
        JButton btnNuevo = new JButton("Nuevo/Limpiar");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnListar = new JButton("Listar");
        acciones.add(btnNuevo); acciones.add(btnGuardar); acciones.add(btnModificar); acciones.add(btnEliminar); acciones.add(btnListar);

        JPanel top = new JPanel(new BorderLayout(6,6));
        JPanel search = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6,6));
        search.add(new JLabel("Buscar:")); search.add(txtBuscar);
        top.add(form, BorderLayout.CENTER); top.add(acciones, BorderLayout.SOUTH); top.add(search, BorderLayout.NORTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnNuevo.addActionListener(e -> limpiar());
        btnListar.addActionListener(e -> cargarTabla());
        btnGuardar.addActionListener(e -> guardar(false));
        btnModificar.addActionListener(e -> guardar(true));
        btnEliminar.addActionListener(e -> eliminar());
        txtBuscar.getDocument().addDocumentListener(SimpleDocListener.onChange(this::cargarTabla));
        table.getSelectionModel().addListSelectionListener(e -> seleccionar());

        cargarTabla();
    }

    private void cargarTabla() {
        try {
            List<Categoria> data = service.listar(txtBuscar.getText());
            DefaultTableModel m = new DefaultTableModel(new Object[]{"ID","Nombre"},0) {
                @Override public boolean isCellEditable(int r, int c){ return false; }
            };
            for (Categoria a : data) m.addRow(new Object[]{a.getId(), a.getNombre()});
            table.setModel(m);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error listando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar(boolean modificar) {
        try {
            Categoria c = new Categoria();
            if (modificar) {
                if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona una categoría"); return; }
                c.setId(Integer.parseInt(txtId.getText()));
            }
            c.setNombre(txtNombre.getText().trim());
            service.guardar(c);
            JOptionPane.showMessageDialog(this, "Guardado correctamente");
            limpiar(); cargarTabla();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error guardando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminar() {
        try {
            if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona una categoría"); return; }
            int id = Integer.parseInt(txtId.getText());
            int opt = JOptionPane.showConfirmDialog(this, "¿Eliminar categoría ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (opt == JOptionPane.YES_OPTION) {
                service.eliminar(id);
                JOptionPane.showMessageDialog(this, "Eliminado");
                limpiar(); cargarTabla();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error eliminando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void seleccionar() {
        int r = table.getSelectedRow();
        if (r >= 0) {
            txtId.setText(String.valueOf(table.getValueAt(r,0)));
            txtNombre.setText(String.valueOf(table.getValueAt(r,1)));
        }
    }

    private void limpiar() {
        txtId.setText(""); txtNombre.setText("");
        table.clearSelection();
    }
}
