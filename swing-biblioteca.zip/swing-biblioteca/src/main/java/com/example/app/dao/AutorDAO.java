package com.example.app.dao;
import com.example.app.model.Autor;
import java.util.List;
public interface AutorDAO {
    void create(Autor a) throws Exception;
    void update(Autor a) throws Exception;
    void delete(int id) throws Exception;
    Autor findById(int id) throws Exception;
    List<Autor> findAll(String filtro) throws Exception;
}
