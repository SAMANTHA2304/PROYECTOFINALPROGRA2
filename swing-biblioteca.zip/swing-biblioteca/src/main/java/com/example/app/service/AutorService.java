package com.example.app.service;

import com.example.app.dao.AutorDAO;
import com.example.app.dao.impl.AutorDAOImpl;
import com.example.app.model.Autor;
import java.util.List;

public class AutorService {
    private final AutorDAO dao = new AutorDAOImpl();

    public void guardar(Autor a) throws Exception {
        if (a.getNombre() == null || a.getNombre().isBlank()) throw new IllegalArgumentException("Nombre requerido");
        if (a.getId() == 0) dao.create(a); else dao.update(a);
    }
    public void eliminar(int id) throws Exception { dao.delete(id); }
    public List<Autor> listar(String filtro) throws Exception { return dao.findAll(filtro); }
}
