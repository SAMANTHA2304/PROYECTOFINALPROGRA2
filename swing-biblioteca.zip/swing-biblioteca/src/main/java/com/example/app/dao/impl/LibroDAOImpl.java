package com.example.app.dao.impl;

import com.example.app.config.DB;
import com.example.app.dao.LibroDAO;
import com.example.app.model.Libro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibroDAOImpl implements LibroDAO {
    @Override
    public void create(Libro l) throws Exception {
        String sql = "INSERT INTO libros(titulo, autor_id, categoria_id, anio, stock) VALUES(?,?,?,?,?)";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setInt(2, l.getAutorId());
            ps.setInt(3, l.getCategoriaId());
            ps.setInt(4, l.getAnio());
            ps.setInt(5, l.getStock());
            ps.executeUpdate();
        }
    }

    @Override
    public void update(Libro l) throws Exception {
        String sql = "UPDATE libros SET titulo=?, autor_id=?, categoria_id=?, anio=?, stock=? WHERE id=?";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setInt(2, l.getAutorId());
            ps.setInt(3, l.getCategoriaId());
            ps.setInt(4, l.getAnio());
            ps.setInt(5, l.getStock());
            ps.setInt(6, l.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void delete(int id) throws Exception {
        String sql = "DELETE FROM libros WHERE id=?";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Libro findById(int id) throws Exception {
        String sql = "SELECT id, titulo, autor_id, categoria_id, anio, stock FROM libros WHERE id=?";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Libro(rs.getInt(1), rs.getString(2), rs.getInt(3),
                            rs.getInt(4), rs.getInt(5), rs.getInt(6));
                }
            }
        }
        return null;
    }

    @Override
    public List<Libro> findAll(String filtro) throws Exception {
        List<Libro> list = new ArrayList<>();
        String sql = "SELECT id, titulo, autor_id, categoria_id, anio, stock FROM libros " +
                     "WHERE (? IS NULL OR titulo LIKE ?) ORDER BY id DESC";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            String like = (filtro == null || filtro.isBlank()) ? null : "%" + filtro + "%";
            if (like == null) { ps.setNull(1, Types.VARCHAR); ps.setNull(2, Types.VARCHAR); }
            else { ps.setString(1, like); ps.setString(2, like); }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Libro(rs.getInt(1), rs.getString(2), rs.getInt(3),
                            rs.getInt(4), rs.getInt(5), rs.getInt(6)));
                }
            }
        }
        return list;
    }
}
