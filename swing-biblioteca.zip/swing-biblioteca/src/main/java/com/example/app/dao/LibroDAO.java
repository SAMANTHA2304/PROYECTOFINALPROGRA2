package com.example.app.dao;
import com.example.app.model.Libro;
import java.util.List;
public interface LibroDAO {
    void create(Libro l) throws Exception;
    void update(Libro l) throws Exception;
    void delete(int id) throws Exception;
    Libro findById(int id) throws Exception;
    List<Libro> findAll(String filtro) throws Exception;
}
