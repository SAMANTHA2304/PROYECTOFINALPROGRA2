package com.example.app.dao.impl;

import com.example.app.config.DB;
import com.example.app.dao.AutorDAO;
import com.example.app.model.Autor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AutorDAOImpl implements AutorDAO {
    @Override
    public void create(Autor a) throws Exception {
        String sql = "INSERT INTO autores(nombre, nacionalidad) VALUES(?,?)";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, a.getNombre());
            ps.setString(2, a.getNacionalidad());
            ps.executeUpdate();
        }
    }

    @Override
    public void update(Autor a) throws Exception {
        String sql = "UPDATE autores SET nombre=?, nacionalidad=? WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, a.getNombre());
            ps.setString(2, a.getNacionalidad());
            ps.setInt(3, a.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void delete(int id) throws Exception {
        String sql = "DELETE FROM autores WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Autor findById(int id) throws Exception {
        String sql = "SELECT id, nombre, nacionalidad FROM autores WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new Autor(rs.getInt(1), rs.getString(2), rs.getString(3));
                return null;
            }
        }
    }

    @Override
    public List<Autor> findAll(String filtro) throws Exception {
        List<Autor> list = new ArrayList<>();
        String sql = "SELECT id, nombre, nacionalidad FROM autores " +
                     "WHERE (? IS NULL OR nombre LIKE ? OR nacionalidad LIKE ?) ORDER BY id DESC";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            String like = (filtro == null || filtro.isBlank()) ? null : "%" + filtro + "%";
            if (like == null) {
                ps.setNull(1, Types.VARCHAR); ps.setNull(2, Types.VARCHAR); ps.setNull(3, Types.VARCHAR);
            } else {
                ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new Autor(rs.getInt(1), rs.getString(2), rs.getString(3)));
            }
        }
        return list;
    }
}
