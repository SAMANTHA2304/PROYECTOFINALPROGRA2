package com.example.app.service;

import com.example.app.dao.UserDAO;
import com.example.app.dao.impl.UserDAOImpl;
import com.example.app.model.User;
import com.example.app.util.PasswordUtil;

public class AuthService {
    private final UserDAO userDAO = new UserDAOImpl();

    public User login(String username, String passwordPlain) throws Exception {
        if (username == null || username.isBlank()) throw new IllegalArgumentException("Usuario requerido");
        if (passwordPlain == null || passwordPlain.isBlank()) throw new IllegalArgumentException("Contraseña requerida");

        User u = userDAO.findByUsername(username);
        if (u == null) throw new IllegalArgumentException("Usuario no encontrado");
        if (!"ACTIVO".equalsIgnoreCase(u.getEstado())) throw new IllegalArgumentException("Usuario inactivo");
        if (!PasswordUtil.verify(passwordPlain, u.getPasswordHash())) throw new IllegalArgumentException("Credenciales inválidas");
        return u;
    }
}
