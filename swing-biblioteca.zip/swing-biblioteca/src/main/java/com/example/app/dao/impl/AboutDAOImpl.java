package com.example.app.dao.impl;

import com.example.app.config.DB;
import com.example.app.dao.AboutDAO;
import com.example.app.model.AboutInfo;

import java.sql.*;

public class AboutDAOImpl implements AboutDAO {
    @Override
    public AboutInfo get() throws Exception {
        String sql = "SELECT id, carne, nombres, numero_carne, foto_path, proyecto, version, fecha FROM acerca_de LIMIT 1";
        try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new AboutInfo(
                    rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getString(7),
                    rs.getDate(8).toLocalDate()
                );
            }
        }
        return null;
    }

    @Override
    public void saveOrUpdate(AboutInfo i) throws Exception {
        AboutInfo current = get();
        if (current == null) {
            String sql = "INSERT INTO acerca_de(carne, nombres, numero_carne, foto_path, proyecto, version, fecha) VALUES(?,?,?,?,?,?,?)";
            try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setString(1, i.getCarne());
                ps.setString(2, i.getNombres());
                ps.setString(3, i.getNumeroCarne());
                ps.setString(4, i.getFotoPath());
                ps.setString(5, i.getProyecto());
                ps.setString(6, i.getVersion());
                ps.setDate(7, Date.valueOf(i.getFecha()));
                ps.executeUpdate();
            }
        } else {
            String sql = "UPDATE acerca_de SET carne=?, nombres=?, numero_carne=?, foto_path=?, proyecto=?, version=?, fecha=? WHERE id=?";
            try (Connection cn = DB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setString(1, i.getCarne());
                ps.setString(2, i.getNombres());
                ps.setString(3, i.getNumeroCarne());
                ps.setString(4, i.getFotoPath());
                ps.setString(5, i.getProyecto());
                ps.setString(6, i.getVersion());
                ps.setDate(7, Date.valueOf(i.getFecha()));
                ps.setInt(8, current.getId());
                ps.executeUpdate();
            }
        }
    }
}
