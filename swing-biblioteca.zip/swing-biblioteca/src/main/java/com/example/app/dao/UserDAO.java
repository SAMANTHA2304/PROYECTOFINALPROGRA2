package com.example.app.dao;
import com.example.app.model.User;
public interface UserDAO {
    User findByUsername(String username) throws Exception;
}
