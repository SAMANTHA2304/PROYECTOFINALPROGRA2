package com.example.app.service;

import com.example.app.dao.CategoriaDAO;
import com.example.app.dao.impl.CategoriaDAOImpl;
import com.example.app.model.Categoria;
import java.util.List;

public class CategoriaService {
    private final CategoriaDAO dao = new CategoriaDAOImpl();

    public void guardar(Categoria c) throws Exception {
        if (c.getNombre() == null || c.getNombre().isBlank()) throw new IllegalArgumentException("Nombre requerido");
        if (c.getId() == 0) dao.create(c); else dao.update(c);
    }
    public void eliminar(int id) throws Exception { dao.delete(id); }
    public List<Categoria> listar(String filtro) throws Exception { return dao.findAll(filtro); }
}
