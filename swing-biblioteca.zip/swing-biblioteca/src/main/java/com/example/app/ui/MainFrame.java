package com.example.app.ui;

import com.example.app.model.User;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final User user;

    public MainFrame(User user) {
        this.user = user;
        setTitle("Menú Principal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(640, 420);
        setLocationRelativeTo(null);

        var bar = new JMenuBar();
        var mArchivo = new JMenu("Archivo");
        var mGestion = new JMenu("Gestión");
        var mAyuda = new JMenu("Ayuda");

        var miAutores = new JMenuItem("Autores");
        var miCategorias = new JMenuItem("Categorías");
        var miLibros = new JMenuItem("Libros");
        var miAcerca = new JMenuItem("Acerca de");
        var miCerrarSesion = new JMenuItem("Cerrar sesión");
        var miSalir = new JMenuItem("Salir");

        miAutores.addActionListener(e -> new AutoresFrame(this).setVisible(true));
        miCategorias.addActionListener(e -> new CategoriasFrame(this).setVisible(true));
        miLibros.addActionListener(e -> new LibrosFrame(this).setVisible(true));
        miAcerca.addActionListener(e -> new AboutFrame(this).setVisible(true));
        miCerrarSesion.addActionListener(e -> { new LoginFrame().setVisible(true); dispose(); });
        miSalir.addActionListener(e -> System.exit(0));

        mGestion.add(miAutores); mGestion.add(miCategorias); mGestion.add(miLibros);
        mAyuda.add(miAcerca);
        mArchivo.add(miCerrarSesion); mArchivo.add(miSalir);

        bar.add(mArchivo); bar.add(mGestion); bar.add(mAyuda);
        setJMenuBar(bar);

        var label = new JLabel("Usuario: " + user.getUsername(), SwingConstants.CENTER);
        add(label, BorderLayout.CENTER);
    }
}
