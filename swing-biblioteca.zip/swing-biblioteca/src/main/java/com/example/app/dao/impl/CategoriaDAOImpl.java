package com.example.app.dao.impl;

import com.example.app.config.DB;
import com.example.app.dao.CategoriaDAO;
import com.example.app.model.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAOImpl implements CategoriaDAO {
    @Override
    public void create(Categoria c) throws Exception {
        String sql = "INSERT INTO categorias(nombre) VALUES(?)";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.executeUpdate();
        }
    }

    @Override
    public void update(Categoria c) throws Exception {
        String sql = "UPDATE categorias SET nombre=? WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void delete(int id) throws Exception {
        String sql = "DELETE FROM categorias WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Categoria findById(int id) throws Exception {
        String sql = "SELECT id, nombre FROM categorias WHERE id=?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new Categoria(rs.getInt(1), rs.getString(2));
                return null;
            }
        }
    }

    @Override
    public List<Categoria> findAll(String filtro) throws Exception {
        List<Categoria> list = new ArrayList<>();
        String sql = "SELECT id, nombre FROM categorias " +
                     "WHERE (? IS NULL OR nombre LIKE ?) ORDER BY id DESC";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            String like = (filtro == null || filtro.isBlank()) ? null : "%" + filtro + "%";
            if (like == null) { ps.setNull(1, Types.VARCHAR); ps.setNull(2, Types.VARCHAR); }
            else { ps.setString(1, like); ps.setString(2, like); }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new Categoria(rs.getInt(1), rs.getString(2)));
            }
        }
        return list;
    }
}
