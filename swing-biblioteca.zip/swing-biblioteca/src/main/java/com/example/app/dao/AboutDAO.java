package com.example.app.dao;
import com.example.app.model.AboutInfo;
public interface AboutDAO {
    AboutInfo get() throws Exception;
    void saveOrUpdate(AboutInfo info) throws Exception;
}
