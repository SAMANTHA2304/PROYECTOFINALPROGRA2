package com.example.app.service;

import com.example.app.dao.AboutDAO;
import com.example.app.dao.impl.AboutDAOImpl;
import com.example.app.model.AboutInfo;

public class AboutService {
    private final AboutDAO dao = new AboutDAOImpl();
    public AboutInfo obtener() throws Exception { return dao.get(); }
    public void guardar(AboutInfo i) throws Exception {
        if (i.getCarne() == null || i.getCarne().isBlank()) throw new IllegalArgumentException("Carné requerido");
        if (i.getNombres() == null || i.getNombres().isBlank()) throw new IllegalArgumentException("Nombres requeridos");
        dao.saveOrUpdate(i);
    }
}
