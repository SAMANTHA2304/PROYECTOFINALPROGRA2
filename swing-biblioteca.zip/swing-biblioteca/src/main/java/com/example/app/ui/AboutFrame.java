package com.example.app.ui;

import com.example.app.model.AboutInfo;
import com.example.app.service.AboutService;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;

public class AboutFrame extends JFrame {
    private final AboutService service = new AboutService();
    private final JTextField txtCarne = new JTextField();
    private final JTextField txtNombres = new JTextField();
    private final JTextField txtNumeroCarne = new JTextField();
    private final JTextField txtProyecto = new JTextField("Biblioteca - Programación II");
    private final JTextField txtVersion = new JTextField("1.0.0");
    private final JFormattedTextField txtFecha = new JFormattedTextField(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE.toFormat());
    private final JLabel lblFoto = new JLabel("Sin foto", SwingConstants.CENTER);
    private String fotoPath;

    public AboutFrame(Frame owner) {
        setTitle("Acerca de");
        setSize(640, 520);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(8,8));

        JPanel form = new JPanel(new GridLayout(7,2,6,6));
        form.setBorder(BorderFactory.createTitledBorder("Datos del Alumno"));
        form.add(new JLabel("Carné")); form.add(txtCarne);
        form.add(new JLabel("Nombres")); form.add(txtNombres);
        form.add(new JLabel("Número de carné")); form.add(txtNumeroCarne);
        form.add(new JLabel("Proyecto")); form.add(txtProyecto);
        form.add(new JLabel("Versión")); form.add(txtVersion);
        form.add(new JLabel("Fecha (YYYY-MM-DD)")); txtFecha.setValue(LocalDate.now()); form.add(txtFecha);

        JButton btnFoto = new JButton("Cargar foto");
        btnFoto.addActionListener(e -> seleccionarFoto());
        form.add(new JLabel("Foto")); form.add(btnFoto);

        JPanel right = new JPanel(new BorderLayout());
        lblFoto.setPreferredSize(new Dimension(220, 280));
        lblFoto.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        right.add(lblFoto, BorderLayout.CENTER);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(e -> guardar());

        add(form, BorderLayout.CENTER);
        add(right, BorderLayout.EAST);
        add(btnGuardar, BorderLayout.SOUTH);

        cargar();
    }

    private void seleccionarFoto() {
        JFileChooser ch = new JFileChooser();
        int r = ch.showOpenDialog(this);
        if (r == JFileChooser.APPROVE_OPTION) {
            File f = ch.getSelectedFile();
            this.fotoPath = f.getAbsolutePath();
            mostrarImagen(fotoPath);
        }
    }

    private void mostrarImagen(String path) {
        try {
            BufferedImage img = ImageIO.read(new File(path));
            Image scaled = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_SMOOTH);
            lblFoto.setIcon(new ImageIcon(scaled));
            lblFoto.setText("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "No se pudo leer la imagen: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargar() {
        try {
            AboutInfo i = service.obtener();
            if (i != null) {
                txtCarne.setText(i.getCarne());
                txtNombres.setText(i.getNombres());
                txtNumeroCarne.setText(i.getNumeroCarne());
                txtProyecto.setText(i.getProyecto());
                txtVersion.setText(i.getVersion());
                txtFecha.setValue(i.getFecha());
                this.fotoPath = i.getFotoPath();
                if (fotoPath != null && !fotoPath.isBlank()) mostrarImagen(fotoPath);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error cargando datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar() {
        try {
            AboutInfo i = new AboutInfo();
            i.setCarne(txtCarne.getText().trim());
            i.setNombres(txtNombres.getText().trim());
            i.setNumeroCarne(txtNumeroCarne.getText().trim());
            i.setProyecto(txtProyecto.getText().trim());
            i.setVersion(txtVersion.getText().trim());
            i.setFecha(LocalDate.parse(txtFecha.getText()));
            i.setFotoPath(fotoPath);
            service.guardar(i);
            JOptionPane.showMessageDialog(this, "Guardado");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error guardando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
