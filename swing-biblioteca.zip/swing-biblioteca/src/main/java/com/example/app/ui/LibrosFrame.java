package com.example.app.ui;

import com.example.app.model.Autor;
import com.example.app.model.Categoria;
import com.example.app.model.Libro;
import com.example.app.service.LibroService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class LibrosFrame extends JFrame {
    private final LibroService service = new LibroService();
    private final JTextField txtId = new JTextField();
    private final JTextField txtTitulo = new JTextField();
    private final JComboBox<Autor> cbAutor = new JComboBox<>();
    private final JComboBox<Categoria> cbCategoria = new JComboBox<>();
    private final JSpinner spAnio = new JSpinner(new SpinnerNumberModel(2024, 0, 3000, 1));
    private final JSpinner spStock = new JSpinner(new SpinnerNumberModel(1, 0, 10000, 1));
    private final JTextField txtBuscar = new JTextField();
    private final JTable table = new JTable();

    public LibrosFrame(Frame owner) {
        setTitle("CRUD Libros");
        setSize(900, 560);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(8,8));

        JPanel form = new JPanel(new GridLayout(6,2,6,6));
        form.setBorder(BorderFactory.createTitledBorder("Formulario"));
        txtId.setEditable(false);
        form.add(new JLabel("ID")); form.add(txtId);
        form.add(new JLabel("Título")); form.add(txtTitulo);
        form.add(new JLabel("Autor")); form.add(cbAutor);
        form.add(new JLabel("Categoría")); form.add(cbCategoria);
        form.add(new JLabel("Año")); form.add(spAnio);
        form.add(new JLabel("Stock")); form.add(spStock);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 6,6));
        JButton btnNuevo = new JButton("Nuevo/Limpiar");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnListar = new JButton("Listar");
        acciones.add(btnNuevo); acciones.add(btnGuardar); acciones.add(btnModificar); acciones.add(btnEliminar); acciones.add(btnListar);

        JPanel top = new JPanel(new BorderLayout(6,6));
        JPanel search = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6,6));
        search.add(new JLabel("Buscar:")); search.add(txtBuscar);
        top.add(form, BorderLayout.CENTER); top.add(acciones, BorderLayout.SOUTH); top.add(search, BorderLayout.NORTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnNuevo.addActionListener(e -> limpiar());
        btnListar.addActionListener(e -> cargarTabla());
        btnGuardar.addActionListener(e -> guardar(false));
        btnModificar.addActionListener(e -> guardar(true));
        btnEliminar.addActionListener(e -> eliminar());
        txtBuscar.getDocument().addDocumentListener(SimpleDocListener.onChange(this::cargarTabla));
        table.getSelectionModel().addListSelectionListener(e -> seleccionar());

        cargarCombos();
        cargarTabla();
    }

    private void cargarCombos() {
        try {
            cbAutor.removeAllItems();
            for (Autor a : service.autores(null)) cbAutor.addItem(a);
            cbCategoria.removeAllItems();
            for (Categoria c : service.categorias(null)) cbCategoria.addItem(c);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error cargando combos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla() {
        try {
            List<Libro> data = service.listar(txtBuscar.getText());
            DefaultTableModel m = new DefaultTableModel(new Object[]{"ID","Título","AutorID","CatID","Año","Stock"},0) {
                @Override public boolean isCellEditable(int r, int c){ return false; }
            };
            for (Libro l : data) m.addRow(new Object[]{l.getId(), l.getTitulo(), l.getAutorId(), l.getCategoriaId(), l.getAnio(), l.getStock()});
            table.setModel(m);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error listando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar(boolean modificar) {
        try {
            Libro l = new Libro();
            if (modificar) {
                if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona un libro"); return; }
                l.setId(Integer.parseInt(txtId.getText()));
            }
            l.setTitulo(txtTitulo.getText().trim());
            Autor a = (Autor) cbAutor.getSelectedItem();
            Categoria c = (Categoria) cbCategoria.getSelectedItem();
            if (a != null) l.setAutorId(a.getId());
            if (c != null) l.setCategoriaId(c.getId());
            l.setAnio((Integer) spAnio.getValue());
            l.setStock((Integer) spStock.getValue());

            service.guardar(l);
            JOptionPane.showMessageDialog(this, "Guardado correctamente");
            limpiar(); cargarTabla();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error guardando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminar() {
        try {
            if (txtId.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Selecciona un libro"); return; }
            int id = Integer.parseInt(txtId.getText());
            int opt = JOptionPane.showConfirmDialog(this, "¿Eliminar libro ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (opt == JOptionPane.YES_OPTION) {
                service.eliminar(id);
                JOptionPane.showMessageDialog(this, "Eliminado");
                limpiar(); cargarTabla();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error eliminando: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void seleccionar() {
        int r = table.getSelectedRow();
        if (r >= 0) {
            txtId.setText(String.valueOf(table.getValueAt(r,0)));
            txtTitulo.setText(String.valueOf(table.getValueAt(r,1)));
        }
    }

    private void limpiar() {
        txtId.setText(""); txtTitulo.setText("");
        spAnio.setValue(2024); spStock.setValue(1);
        table.clearSelection();
    }
}
