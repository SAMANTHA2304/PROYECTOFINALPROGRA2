package com.example.app.dao;
import com.example.app.model.Categoria;
import java.util.List;
public interface CategoriaDAO {
    void create(Categoria c) throws Exception;
    void update(Categoria c) throws Exception;
    void delete(int id) throws Exception;
    Categoria findById(int id) throws Exception;
    List<Categoria> findAll(String filtro) throws Exception;
}
