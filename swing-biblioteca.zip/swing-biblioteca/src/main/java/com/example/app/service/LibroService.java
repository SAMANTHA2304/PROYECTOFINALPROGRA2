package com.example.app.service;

import com.example.app.dao.AutorDAO;
import com.example.app.dao.CategoriaDAO;
import com.example.app.dao.LibroDAO;
import com.example.app.dao.impl.AutorDAOImpl;
import com.example.app.dao.impl.CategoriaDAOImpl;
import com.example.app.dao.impl.LibroDAOImpl;
import com.example.app.model.Autor;
import com.example.app.model.Categoria;
import com.example.app.model.Libro;

import java.util.List;

public class LibroService {
    private final LibroDAO dao = new LibroDAOImpl();
    private final AutorDAO autorDAO = new AutorDAOImpl();
    private final CategoriaDAO categoriaDAO = new CategoriaDAOImpl();

    public void guardar(Libro l) throws Exception {
        if (l.getTitulo() == null || l.getTitulo().isBlank()) throw new IllegalArgumentException("Título requerido");
        if (l.getAutorId() <= 0) throw new IllegalArgumentException("Autor requerido");
        if (l.getCategoriaId() <= 0) throw new IllegalArgumentException("Categoría requerida");
        if (l.getAnio() < 0) throw new IllegalArgumentException("Año inválido");
        if (l.getStock() < 0) throw new IllegalArgumentException("Stock inválido");
        if (l.getId() == 0) dao.create(l); else dao.update(l);
    }

    public void eliminar(int id) throws Exception { dao.delete(id); }
    public List<Libro> listar(String filtro) throws Exception { return dao.findAll(filtro); }

    public List<Autor> autores(String filtro) throws Exception { return autorDAO.findAll(filtro); }
    public List<Categoria> categorias(String filtro) throws Exception { return categoriaDAO.findAll(filtro); }
}
