package com.example.app.dao.impl;

import com.example.app.config.DB;
import com.example.app.dao.UserDAO;
import com.example.app.model.User;
import java.sql.*;

public class UserDAOImpl implements UserDAO {
    @Override
    public User findByUsername(String username) throws Exception {
        String sql = "SELECT id, username, password_hash, rol, estado FROM usuarios WHERE username = ?";
        try (Connection cn = DB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password_hash"),
                        rs.getString("rol"),
                        rs.getString("estado")
                    );
                }
                return null;
            }
        }
    }
}
