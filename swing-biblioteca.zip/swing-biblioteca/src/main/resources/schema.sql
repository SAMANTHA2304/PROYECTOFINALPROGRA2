CREATE DATABASE IF NOT EXISTS biblioteca CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE biblioteca;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  rol VARCHAR(20) NOT NULL DEFAULT 'ADMIN',
  estado VARCHAR(20) NOT NULL DEFAULT 'ACTIVO'
);

CREATE TABLE IF NOT EXISTS autores (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  nacionalidad VARCHAR(80) NULL
);

CREATE TABLE IF NOT EXISTS categorias (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS libros (
  id INT PRIMARY KEY AUTO_INCREMENT,
  titulo VARCHAR(200) NOT NULL,
  autor_id INT NOT NULL,
  categoria_id INT NOT NULL,
  anio INT NOT NULL,
  stock INT NOT NULL,
  CONSTRAINT fk_libro_autor FOREIGN KEY (autor_id) REFERENCES autores(id) ON DELETE RESTRICT,
  CONSTRAINT fk_libro_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS acerca_de (
  id INT PRIMARY KEY AUTO_INCREMENT,
  carne VARCHAR(50) NOT NULL,
  nombres VARCHAR(120) NOT NULL,
  numero_carne VARCHAR(50) NOT NULL,
  foto_path VARCHAR(400) NULL,
  proyecto VARCHAR(150) NOT NULL,
  version VARCHAR(20) NOT NULL,
  fecha DATE NOT NULL
);

-- admin / admin123
INSERT INTO usuarios (username, password_hash, rol, estado) VALUES
('admin', '$2a$12$yqzF3a3i3G2M1Qx1oXb2Ae9wPZp7q8n3eQqj9sQnKq1o8P7w0qg2e', 'ADMIN', 'ACTIVO')
ON DUPLICATE KEY UPDATE username=username;

INSERT INTO autores (nombre, nacionalidad) VALUES
('Gabriel García Márquez','Colombia'),
('Isabel Allende','Chile')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);

INSERT INTO categorias (nombre) VALUES
('Novela'),
('Cuento')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);

INSERT INTO libros (titulo, autor_id, categoria_id, anio, stock) VALUES
('Cien años de soledad', 1, 1, 1967, 5),
('La casa de los espíritus', 2, 1, 1982, 3);
